package vn.com.enablecode.tikiproject;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;

import vn.com.enablecode.tikiproject.Adapter.DichVuAdapter;
import vn.com.enablecode.tikiproject.Adapter.HotTagAdapter;
import vn.com.enablecode.tikiproject.Model.DichVu;
import vn.com.enablecode.tikiproject.Model.HotTag;

public class HomeActivity extends AppCompatActivity {

    //Khai báo phần dịch vụ
    GridView gvDichVu;
    DichVuAdapter dichVuAdapter;
    ArrayList<DichVu> dsDichVu;

    //Khai báo phần từ khoá hot
    GridView gvTuKhoaHot;
    HotTagAdapter hotTagAdapter;
    ArrayList<HotTag> dsTuKhoaHot;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        addControls();
        addEvents();
    }

    private void addEvents() {
        gvDichVu.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DichVu dichVu=dichVuAdapter.getItem(position);
                //Khi chọn 1 dịch vụ thì sẽ dẫn đến Activity Dịch vụ đó,
                //ở đây mình chỉ shown thông báo toast để biết mình link mình hoạt động ổn
                Toast.makeText(HomeActivity.this, "Bạn chọn dịch vụ " + dichVu.getName(), Toast.LENGTH_SHORT).show();
            }
        });

        gvTuKhoaHot.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HotTag hotTag=hotTagAdapter.getItem(position);
                //Khi chọn 1 từ khoá thì sẽ dẫn đến Activity từ khoá đó,
                //ở đây mình chỉ shown thông báo toast để biết mình link mình hoạt động ổn
                Toast.makeText(HomeActivity.this, "Bạn chọn từ khoá " + hotTag.getName(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addControls() {
        //Dịch vụ
        gvDichVu=findViewById(R.id.gvDichVu);
        dsDichVu=new ArrayList<>();
        dsDichVu=getDataDichVu();
        dichVuAdapter=new DichVuAdapter(HomeActivity.this,R.layout.item_dich_vu,dsDichVu);
        gvDichVu.setAdapter(dichVuAdapter);
        gridViewSetting(gvDichVu, 150, dsDichVu);


        //Từ khoá hot
        gvTuKhoaHot=findViewById(R.id.gvTuKhoa);
        dsTuKhoaHot=new ArrayList<>();
        dsTuKhoaHot=getDataTuKhoaHot();
        hotTagAdapter=new HotTagAdapter(HomeActivity.this,R.layout.item_hot_tag,dsTuKhoaHot);
        gvTuKhoaHot.setAdapter(hotTagAdapter);
        gridViewSetting(gvTuKhoaHot,130, dsTuKhoaHot);



    }


    //Bước này gọi từ API về, nhưng ở đây để giảm thiểu lượng code nên mình cho data demo
    public ArrayList<DichVu> getDataDichVu()
    {
        ArrayList<DichVu> listDichVu = new ArrayList<>();
        listDichVu.add(new DichVu(1, R.drawable.airplane, "Vé Máy Bay", "#"));
        listDichVu.add(new DichVu(2, R.drawable.bao_hiem, "Mua Bảo hiểm online ", "#"));
        listDichVu.add(new DichVu(3, R.drawable.the_cao, "Mua Thẻ điện thoại", "#"));
        listDichVu.add(new DichVu(4, R.drawable.airplane, "Thẻ Game", "#"));
        return listDichVu;
    }

    //Bước này gọi từ API về, Dữ liệu từ khoá hot demo
    public ArrayList<HotTag> getDataTuKhoaHot()
    {
        ArrayList<HotTag> listHotTag = new ArrayList<>();
        listHotTag.add(new HotTag(1, "Đồng hồ", "#223344", "#"));
        listHotTag.add(new HotTag(2, "Điện thoại", "#222222", "#"));
        listHotTag.add(new HotTag(3, "Laptop", "#000333", "#"));
        listHotTag.add(new HotTag(4, "Máy tính bảng", "#000000", "#"));
        listHotTag.add(new HotTag(5, "Giày Nam", "#220088", "#"));
        listHotTag.add(new HotTag(6, "Tủ Lạnh", "#003344", "#"));
        listHotTag.add(new HotTag(7, "Tivi", "#220044", "#"));
        listHotTag.add(new HotTag(8, "Quần áo", "#000044", "#"));
        return listHotTag;
    }

    private void gridViewSetting(GridView gridview, int width, ArrayList ds) {

        int size=ds.size();
        DisplayMetrics dm = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(dm);
        float density = dm.density;
        int totalWidth = (int) (width * size * density);
        int singleItemWidth = (int) (width * density);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                totalWidth, LinearLayout.LayoutParams.MATCH_PARENT);
        gridview.setLayoutParams(params);
        gridview.setColumnWidth(singleItemWidth);
        gridview.setHorizontalSpacing(2);
        gridview.setStretchMode(GridView.STRETCH_SPACING);
        gridview.setNumColumns(size);
    }



}
