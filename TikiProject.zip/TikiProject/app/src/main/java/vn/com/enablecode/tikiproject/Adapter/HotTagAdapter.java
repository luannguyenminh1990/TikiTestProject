package vn.com.enablecode.tikiproject.Adapter;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import vn.com.enablecode.tikiproject.Model.HotTag;
import vn.com.enablecode.tikiproject.R;

public class HotTagAdapter extends ArrayAdapter<HotTag> {
    Activity context;
    int resource;
    List<HotTag> objects;


    public HotTagAdapter(Activity context, int resource, List<HotTag> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = this.context.getLayoutInflater().inflate(this.resource, null);
        TextView txtTenTuKhoa = (TextView) view.findViewById(R.id.txtItemTenTuKhoa);
        HotTag hotTag=this.getItem(position);
        txtTenTuKhoa.setText(hotTag.getName());
        txtTenTuKhoa.setBackgroundColor(Color.parseColor(hotTag.getColor()));
        return view;
    }
}
