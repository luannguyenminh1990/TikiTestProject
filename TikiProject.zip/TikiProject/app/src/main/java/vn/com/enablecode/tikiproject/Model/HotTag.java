package vn.com.enablecode.tikiproject.Model;

import java.io.Serializable;

public class HotTag implements Serializable {
    private int code; //ID từ khoá
    private String name;//Tên từ khoá
    private String color;//Màu nền từ khoá
    private String link;//Link tới activity

    public HotTag() {
    }

    public HotTag(int code, String name, String color, String link) {
        this.code = code;
        this.name = name;
        this.color = color;
        this.link = link;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
