package vn.com.enablecode.tikiproject.Adapter;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import vn.com.enablecode.tikiproject.Model.DichVu;
import vn.com.enablecode.tikiproject.R;

public class DichVuAdapter extends ArrayAdapter<DichVu> {
    Activity context;
    int resource;
    List<DichVu> objects;


    public DichVuAdapter(Activity context, int resource, List<DichVu> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View view = this.context.getLayoutInflater().inflate(this.resource, null);

        TextView txtTenDichVu = (TextView) view.findViewById(R.id.txtTenDichVu);
        ImageView imgIcon = view.findViewById(R.id.imgIconDichVu);

        DichVu dichVu=this.getItem(position);
        txtTenDichVu.setText(dichVu.getName());
        imgIcon.setImageDrawable(this.context.getResources().getDrawable(dichVu.getIntImg()));
        return view;
    }
}
