package vn.com.enablecode.tikiproject.Model;

import android.graphics.Bitmap;

import java.io.Serializable;

public class DichVu implements Serializable {
    private int code; //ID dich vu
    private int intImg;//địa chỉ hình drawable
    private Bitmap bmImg;//Dùng để hiển thị ảnh với link từ internet
    private String name;//Tên dịch vụ
    private String link;//Link tới activity

    public DichVu() {
    }

    public DichVu(int code, int intImg, Bitmap bmImg, String name, String link) {
        this.code = code;
        this.intImg = intImg;
        this.bmImg = bmImg;
        this.name = name;
        this.link = link;
    }

    public DichVu(int code, int intImg, String name, String link) {
        this.code = code;
        this.intImg = intImg;
        this.name = name;
        this.link = link;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getIntImg() {
        return intImg;
    }

    public void setIntImg(int intImg) {
        this.intImg = intImg;
    }

    public Bitmap getBmImg() {
        return bmImg;
    }

    public void setBmImg(Bitmap bmImg) {
        this.bmImg = bmImg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
